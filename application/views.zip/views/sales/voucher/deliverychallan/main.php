<?php 
$this->load->view($loadControls);
?>
<div class="page-content-inner">
<div class="portlet light portlet-fit ">
<div class="portlet-body all-data">
<?php 
$this->load->view($loadVoucher);
?>
</div>
</div>
</div>
<!------edit row portion--->
<script>
$(window).on("load",function(){
baseUrl="<?= base_url("sales/delivery-challan")?>";		
});
$(document).on("change","[name=vname]",function(){
if($(this).val()!=""){
var target=$('[load-lcinfo]');	
target.customPreloader("show");
$.post(baseUrl+"/loadso",{vcode:$(this).val()},function(response){
target.html(response);	
});
}	
});
</script>