<div class="row">

<div class="page-content-inner col-sm-12">
<div class="portlet light portlet-fit ">
<div class="portlet-title">
<div class="caption">
<i class="icon-plus font-white"></i>
<span class="caption-subject font-white bold uppercase">Change Password</span>
</div>
</div>
<div class="portlet-body">
<form class="form-horizontal list-refresh" role="form">
<div class="form-body">

<div class="form-group">
<label class="col-md-3 control-label">Current Password</label>
<div class="col-md-4 show-error">
<input type="password" class="form-control" name="cpassword" placeholder="Current Password">
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label"> New Password</label>
<div class="col-md-4 show-error">
<input type="password" class="form-control" name="npassword" placeholder="New Password">
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label">Confirm New Password</label>
<div class="col-md-4 show-error">
<input type="password" class="form-control" name="cnpassword" placeholder="Confirm New Password">
</div>
</div>


</div>
<div class="form-actions right1">
<button type="submit" class="btn green">Submit</button>
<button type="reset" class="btn default">Reset</button>
</div>
</form>
</div>
</div>
</div>


</div>