<form class="form-horizontal action-url-extra edit-form" role="form" action="<?= base_url("chart-of-account-details/employee");?>" onsubmit="return false" >
<input type="hidden" name="id" value="<?= $id;?>" />

<div class="form-body">
<div class="form-group">
<div class="col-md-12">
<div class="note note-success">
<h3 style="margin:0;text-align:center"><b><i class="icon-badge"></i> <?= $name[0]['ANAME']?></b></h3>
</div>
</div>
</div>
<div class="row">
<div class="col-md-6">



<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Full Name</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_fullname" placeholder="Full Name" name="e_fullname" >
</div>
</div> 

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Address</label>
<div class="col-md-9 show-error">
<textarea type="text" class="form-control" id="e_addr" placeholder="Address" name="e_addr"	style="resize:none;"></textarea>
</div>
</div>



<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Mobile</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_mnum" placeholder="Mobile" name="e_mnum" >
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Mobile 2</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_mnum2" placeholder="Mobile 2" name="e_mnum2" >
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Emergency No.</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_emergency" placeholder="Emergency" name="e_emergency" >
</div>
</div>


<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Email</label>

<div class="col-md-9 show-error">
<input type="Email" class="form-control" id="e_mail" placeholder="Email" name="e_mail" >
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Cnic</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_cnic" placeholder="Cnic" name="e_cnic" >
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">City</label>

<div class="col-md-9 show-error">
<select name="e_city"  id="e_city" class="form-control select2">
<option value="">Select City</option>
<?php 
if(count($city)){
foreach($city as $g){
?>
<option value="<?= $g['CCODE'];?>"><?= $g['CNAME']; ?></option>
<?php
}
}
?>
</select>
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Branch</label>

<div class="col-md-9 show-error">
<select name="e_branch"  id="e_branch" class="form-control select2">
<option value="">Select Branch</option>
<?php 
if(count($branch)){
foreach($branch as $g){
?>
<option value="<?= $g['BCODE'];?>"><?= $g['BNAME']; ?></option>
<?php
}
}
?>
</select>
</div>
</div>




</div>

<div class="col-md-6">

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Father Name</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_father" placeholder="Father Name" name="e_father" >
</div>
</div> 

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Blood Group</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_bgroup" placeholder="Blood Group" name="e_bgroup" >
</div>
</div> 


<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Reference</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control" id="e_ref" placeholder="Reference" name="e_ref" >
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">DOB</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control date-picker" id="e_dob" placeholder="dd/mm/yyyy" name="e_dob" >
</div>
</div>


<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Joing Date</label>

<div class="col-md-9 show-error">
<input type="text" class="form-control date-picker" id="e_jdate" placeholder="dd/mm/yyyy" name="e_jdate" >
</div>
</div>



<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Department</label>

<div class="col-md-9 show-error">
<select name="e_department"  id="e_department" class="form-control select2">
<option value="">Select Department</option>
<?php 
if(count($department)){
foreach($department as $g){
?>
<option value="<?= $g['ID'];?>"><?= $g['UDEPT']; ?></option>
<?php
}
}
?>
</select>
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Designation</label>

<div class="col-md-9 show-error">
<select name="e_designation"  id="e_designation" class="form-control select2">
<option value="">Select Designation</option>
<?php 
if(count($designation)){
foreach($designation as $g){
?>
<option value="<?= $g['ID'];?>"><?= $g['UDESIG']; ?></option>
<?php
}
}
?>
</select>
</div>
</div>


<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Username</label>

<div class="col-md-9 show-error">
<select name="e_user"  id="e_user" class="form-control select2">
<option value="">Select Username</option>
<?php 
if(count($users)){
foreach($users as $g){
?>
<option value="<?= $g['USERNAME'];?>"><?= $g['USERNAME']; ?></option>
<?php
}
}
?>
</select>
</div>
</div>

<div class="form-group">
<label for="field-1" class="col-md-3 control-label" style="color:black;">Status</label>

<div class="col-md-9 show-error">
<select name="e_status"  id="e_status" class="form-control select2">
<option value="">Select Status</option>
<option value="0">Permanent</option>
<option value="1">Temporary</option>
<option value="2">Daily Wages</option>
<option value="3">Contract</option>
</select>
</div>
</div>

</div>


</div>








</div>
<div class="form-actions">
<button type="submit" class="btn green">Update</button>
<button type="button" class="btn default" data-dismiss="modal" >Close</button>
</div>
</form>
<script>
$.fn.select2.defaults.set("theme", "bootstrap");
var thisFrom=$('.action-url-extra');
<?php 
if(!empty($employee)){
$dob="";
if($employee[0]['DOB']!=""){
$dob=date("d/m/Y",strtotime($employee[0]['DOB']));	
}
$jdate="";
if($employee[0]['DOB']!=""){
$jdate=date("d/m/Y",strtotime($employee[0]['JDATE']));	
}
if($dob=='01/01/1970'){
$dob="";	
}
if($jdate=='01/01/1970'){
$jdate="";	
}	
?>
thisFrom.find('[name=e_fullname]').val('<?= $employee[0]['FULLNAME']?>');
thisFrom.find('[name=e_mnum2]').val('<?= $employee[0]['MOBILE2']?>');
thisFrom.find('[name=e_cnic]').val('<?= $employee[0]['CNIC']?>');
thisFrom.find('[name=e_city]').val('<?= $employee[0]['CID']?>');
thisFrom.find('[name=e_branch]').val('<?= $employee[0]['BID']?>');
thisFrom.find('[name=e_father]').val('<?= $employee[0]['FATHER']?>');
thisFrom.find('[name=e_bgroup]').val('<?= $employee[0]['BGROUP']?>');
thisFrom.find('[name=e_addr]').val('<?= $employee[0]['ADDR']?>');
thisFrom.find('[name=e_mnum]').val('<?= $employee[0]['MOBILE']?>');
thisFrom.find('[name=e_emergency]').val('<?= $employee[0]['EMERGENCY']?>');
thisFrom.find('[name=e_mail]').val('<?= $employee[0]['EMAIL']?>');
thisFrom.find('[name=e_ref]').val('<?= $employee[0]['REFERENCE']?>');
thisFrom.find('[name=e_dob]').val('<?= $dob?>');
thisFrom.find('[name=e_jdate]').val('<?= $jdate?>');
thisFrom.find('[name=e_department]').val('<?= $employee[0]['DPID']?>');
thisFrom.find('[name=e_designation]').val('<?= $employee[0]['DSID']?>');
thisFrom.find('[name=e_user]').val('<?= $employee[0]['USERNAME']?>');
thisFrom.find('[name=e_status]').val('<?= $employee[0]['STATUS']?>');
<?php 	
}
?>
thisFrom.find('.select2').select2({width:"100%"});
thisFrom.find(".date-picker").datepicker({rtl:App.isRTL(),orientation:"left",autoclose:!0,format:"dd/mm/yyyy",todayHighlight:true});
</script>