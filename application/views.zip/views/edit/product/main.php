<div class="row">

<div class="page-content-inner col-sm-6">
<div class="portlet light portlet-fit ">
<div class="portlet-title">
<div class="caption">
<i class="icon-plus font-white"></i>
<span class="caption-subject font-white bold uppercase">Add Product</span>
</div>
</div>
<div class="portlet-body">
<form class="form-horizontal list-refresh" role="form">
<div class="form-body">

<div class="form-group">
<label class="col-md-3 control-label">Main Group</label>
<div class="col-md-9 show-error">
<select name="mgroup" id="mgroup" class="form-control select2">
<option value="">Select Main Group</option>
<?php 
if(count($mgroup)){
foreach($mgroup as $g){
?>
<option value="<?= $g['ID']."-".$g['MGROUP'];?>"><?= $g['MGROUP']; ?></option>
<?php
}
}
?>
</select>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Size</label>
<div class="col-md-6 show-error">
<select name="size" id="size" class="form-control select2">
<option value="">Select Size</option>
<option value="0">None</option>
<?php 
if(count($size)){
foreach($size as $g){
?>
<option value="<?= $g['ID']."-".$g['SIZE']; ?>"><?= $g['SIZE']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_size">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Outer Dia</label>
<div class="col-md-6 show-error">
<select name="outerdia" id="outerdia" class="form-control select2">
<option value="">Select Outer Dia</option>
<option value="0">None</option>
<?php 
if(count($outerdia)){
foreach($outerdia as $g){
?>
<option value="<?= $g['ID']."-".$g['OUTERDIA']; ?>"><?= $g['OUTERDIA']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_outerdia">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Inner Dia</label>
<div class="col-md-6 show-error">
<select name="innerdia" id="innerdia" class="form-control select2">
<option value="">Select Inner Dia</option>
<option value="0">None</option>
<?php 
if(count($innerdia)){
foreach($innerdia as $g){
?>
<option value="<?= $g['ID']."-".$g['INNERDIA']; ?>"><?= $g['INNERDIA']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_innerdia">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Coil</label>
<div class="col-md-6 show-error">
<select name="coil" id="coil" class="form-control select2">
<option value="">Select Coil</option>
<option value="0">None</option>
<?php 
if(count($coil)){
foreach($coil as $g){
?>
<option value="<?= $g['ID']."-".$g['COIL']; ?>"><?= $g['COIL']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_coil">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Others</label>
<div class="col-md-6 show-error">
<select name="others" id="others" class="form-control select2">
<option value="">Select Others</option>
<option value="0">None</option>
<?php 
if(count($others)){
foreach($others as $g){
?>
<option value="<?= $g['ID']."-".$g['OTHERS']; ?>"><?= $g['OTHERS']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_others">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Gauge</label>
<div class="col-md-6 show-error">
<select name="gauge" id="gauge" class="form-control select2">
<option value="">Select Gauge</option>
<option value="0">None</option>
<?php 
if(count($gauge)){
foreach($gauge as $g){
?>
<option value="<?= $g['ID']."-".$g['GAUGE']; ?>"><?= $g['GAUGE']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_gauge">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Feet</label>
<div class="col-md-6 show-error">
<select name="feet" id="feet" class="form-control select2">
<option value="">Select Feet</option>
<option value="0">None</option>
<?php 
if(count($feet)){
foreach($feet as $g){
?>
<option value="<?= $g['ID']."-".$g['FEET']; ?>"><?= $g['FEET']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_feet">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Unit</label>
<div class="col-md-6 show-error">
<select name="unit" id="unit" class="form-control select2">
<option value="">Select Unit</option>
<option value="0">None</option>
<?php 
if(count($unit)){
foreach($unit as $g){
?>
<option value="<?= $g['ID']."-".$g['UNIT']; ?>"><?= $g['UNIT']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_unit">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Nature</label>
<div class="col-md-6 show-error">
<select name="nature" id="nature" class="form-control select2">
<option value="">Select Nature</option>
<option value="0">None</option>
<?php 
if(count($nature)){
foreach($nature as $g){
?>
<option value="<?= $g['ID']."-".$g['NATURE']; ?>"><?= $g['NATURE']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_nature">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Weight</label>
<div class="col-md-6 show-error">
<select name="weight" id="weight" class="form-control select2">
<option value="">Select Weight</option>
<option value="0">None</option>
<?php 
if(count($weight)){
foreach($weight as $g){
?>
<option value="<?= $g['ID']."-".$g['WEIGHT']; ?>"><?= $g['WEIGHT']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_weight">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Cr/HR Type</label>
<div class="col-md-6 show-error">
<select name="hrtype" id="hrtype" class="form-control select2">
<option value="">Select Cr/HR Type</option>
<option value="0">None</option>
<?php 
if(count($hrtype)){
foreach($hrtype as $g){
?>
<option value="<?= $g['ID']."-".$g['HRTYPE']; ?>"><?= $g['HRTYPE']; ?></option>
<?php
}
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" checked name="inc_hrtype">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Code</label>
<div class="col-md-9 show-error">
<input type="text" class="form-control" name="code" readonly placeholder="Code">
</div>
</div>


<div class="form-group">
<label class="col-md-3 control-label">Name</label>
<div class="col-md-9 show-error">
<input type="text" class="form-control" name="name" title="asdasd" readonly placeholder="Name">
</div>
</div>

</div>
<div class="form-actions right1">
<button type="submit" class="btn green">Submit</button>
<button type="reset" class="btn default">Reset</button>
</div>
</form>
</div>
</div>
</div>
<div class="page-content-inner col-sm-6">
<div class="portlet light portlet-fit ">
<div class="portlet-title">
<div class="caption">
<i class="icon-list font-white"></i>
<span class="caption-subject font-white bold uppercase">List Product</span>
</div>
<div class="actions">
<a class="btn btn-circle btn-icon-only btn-default loadlist" href="javascript:;">
<i class="icon-refresh"></i>
</a>
<a class="btn btn-circle btn-icon-only btn-default fullscreen" href="javascript:;" data-original-title="" title=""> </a>
</div>
</div>
<div class="portlet-body" data-list-load>

</div>
</div>
</div>

</div>
<script>
$(document).on("change",'[name=mgroup],[name=size],[name=outerdia],[name=innerdia],[name=coil],[name=others],[name=gauge],[name=feet],[name=unit],[name=nature],[name=weight],[name=hrtype],[name=inc_size],[name=inc_outerdia],[name=inc_innerdia],[name=inc_gauge],[name=inc_feet],[name=inc_unit],[name=inc_nature],[name=inc_weight],[name=inc_hrtype],[name=inc_others],[name=inc_coil]',function(){
var obj=$(this);
if(obj.val()!="" || obj.is("checkbox"))
{	
var form=obj.parents("form");
var data=form.serializeArray();	
$.ajax({
method:'post',
url:"<?= base_url("edit/product/get-code-name")?>",
data:data,
dataType:"json"	
}).done(function(response){
form.find("[name=name]").val(response.name);	
form.find("[name=name]").attr("title",response.name);	
form.find("[name=code]").val(response.code);	
});
}
});
</script>