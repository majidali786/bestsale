<form class="form-horizontal list-refresh edit-form" role="form">
<input type="hidden" name="id" value="<?= $data[0]['PCODE']?>" />
<div class="form-body">


<div class="form-group">
<label class="col-md-3 control-label">Main Group</label>
<div class="col-md-9 show-error">
<select name="mgroup" id="mgroup" class="form-control select2">
<?php 
if(count($mgroup)){
foreach($mgroup as $g){
?>
<option value="<?= $g['ID']."-".$g['MGROUP'];?>"><?= $g['MGROUP']; ?></option>
<?php
}
}
?>
</select>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Size</label>
<div class="col-md-6 show-error">
<select name="size" id="size" class="form-control select2">
<?php 
if(count($size)){
foreach($size as $g){
?>
<option value="<?= $g['ID']."-".$g['SIZE']; ?>"><?= $g['SIZE']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_SIZE']==1){ echo "checked"; } ?> name="inc_size">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Outer Dia</label>
<div class="col-md-6 show-error">
<select name="outerdia" id="outerdia" class="form-control select2">
<?php 
if(count($outerdia)){
foreach($outerdia as $g){
?>
<option value="<?= $g['ID']."-".$g['OUTERDIA']; ?>"><?= $g['OUTERDIA']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_OUTERDIA']==1){ echo "checked"; } ?> name="inc_outerdia">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Inner Dia</label>
<div class="col-md-6 show-error">
<select name="innerdia" id="innerdia" class="form-control select2">
<?php 
if(count($innerdia)){
foreach($innerdia as $g){
?>
<option value="<?= $g['ID']."-".$g['INNERDIA']; ?>"><?= $g['INNERDIA']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_INNERDIA']==1){ echo "checked"; } ?> name="inc_innerdia">
<span></span>
</label>
</div>
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label">Coil</label>
<div class="col-md-6 show-error">
<select name="coil" id="coil" class="form-control select2">
<?php 
if(count($coil)){
foreach($coil as $g){
?>
<option value="<?= $g['ID']."-".$g['COIL']; ?>"><?= $g['COIL']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_COIL']==1){ echo "checked"; } ?> name="inc_coil">
<span></span>
</label>
</div>
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label">Others</label>
<div class="col-md-6 show-error">
<select name="others" id="others" class="form-control select2">
<?php 
if(count($others)){
foreach($others as $g){
?>
<option value="<?= $g['ID']."-".$g['OTHERS']; ?>"><?= $g['OTHERS']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_OTHERS']==1){ echo "checked"; } ?> name="inc_others">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Gauge</label>
<div class="col-md-6 show-error">
<select name="gauge" id="gauge" class="form-control select2">
<?php 
if(count($gauge)){
foreach($gauge as $g){
?>
<option value="<?= $g['ID']."-".$g['GAUGE']; ?>"><?= $g['GAUGE']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_GAUGE']==1){ echo "checked"; } ?> name="inc_gauge">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Feet</label>
<div class="col-md-6 show-error">
<select name="feet" id="feet" class="form-control select2">
<?php 
if(count($feet)){
foreach($feet as $g){
?>
<option value="<?= $g['ID']."-".$g['FEET']; ?>"><?= $g['FEET']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_FEET']==1){ echo "checked"; } ?> name="inc_feet">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Unit</label>
<div class="col-md-6 show-error">
<select name="unit" id="unit" class="form-control select2">
<?php 
if(count($unit)){
foreach($unit as $g){
?>
<option value="<?= $g['ID']."-".$g['UNIT']; ?>"><?= $g['UNIT']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_UNIT']==1){ echo "checked"; } ?> name="inc_unit">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Nature</label>
<div class="col-md-6 show-error">
<select name="nature" id="nature" class="form-control select2">
<?php 
if(count($nature)){
foreach($nature as $g){
?>
<option value="<?= $g['ID']."-".$g['NATURE']; ?>"><?= $g['NATURE']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_NATURE']==1){ echo "checked"; } ?> name="inc_nature">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Weight</label>
<div class="col-md-6 show-error">
<select name="weight" id="weight" class="form-control select2">
<?php 
if(count($weight)){
foreach($weight as $g){
?>
<option value="<?= $g['ID']."-".$g['WEIGHT']; ?>"><?= $g['WEIGHT']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_WEIGHT']==1){ echo "checked"; } ?> name="inc_weight">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Cr/HR Type</label>
<div class="col-md-6 show-error">
<select name="hrtype" id="hrtype" class="form-control select2">
<?php 
if(count($hrtype)){
foreach($hrtype as $g){
?>
<option value="<?= $g['ID']."-".$g['HRTYPE']; ?>"><?= $g['HRTYPE']; ?></option>
<?php
}
}
else{
echo '<option value="0">None</option>';	
}
?>
</select>
</div>
<div class="col-md-3">
<div class="mt-checkbox-list">
<label class="mt-checkbox mt-checkbox-outline"> Include
<input type="checkbox" value="1" <?php if($data[0]['INC_HRTYPE']==1){ echo "checked"; } ?> name="inc_hrtype">
<span></span>
</label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-3 control-label">Name</label>
<div class="col-md-9 show-error">
<input type="text" class="form-control" name="name" title="<?= $data[0]['PNAME']?>" readonly placeholder="Name" value="<?= $data[0]['PNAME']?>">
</div>
</div>


</div>
<div class="form-actions">
<button type="submit" class="btn green">Update</button>
<button type="button" class="btn default" data-dismiss="modal" >Close</button>
</div>
</form>