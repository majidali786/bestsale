<?php 
$this->load->view($loadControls);
?>
<div class="page-content-inner">
<div class="portlet light portlet-fit ">
<div class="portlet-body all-data">
<?php 
$this->load->view($loadVoucher);
?>
</div>
</div>
</div>
<!------edit row portion--->
<div class="modal fade modal-edit-row" id="basic"  role="basic" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header modal-header-custom">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
<h4 class="modal-title"><?= $heading?></h4>
</div>
<div class="modal-body">
</div>
</div>
</div>
</div>
<script>
$(window).on("load",function(){
baseUrl="<?= base_url("memo/memo-voucher")?>";		
});	
$(document).on("change","[name=type]",function(){	
var val=$(this).val();
setTimeout(function(){
$(document).find("[name=department]").select2("close");
},100);
var target=$("[load-by-type]");
var target2=$(".modal-edit-row").find(".modal-body");
if(val!=''){
target.customPreloader("show");	
target2.customPreloader("show");	
 $.ajax({
 url:"<?= base_url("memo/memo-voucher-type");?>",
 method:"post",
 data:{type:val},
 dataType:"json"	
 }).done(function(response){
 target.html(response.data1);	
 target2.html(response.data2);
 reinitializeTable(1); 
 setTimeout(function(){
 $(document).find("[name=department]").focus();	 
 },100);
 });
}	
});
$(document).on("change","[name=unit]",function(){
var val=$(this).val();
if(val=="feet"){
$(document).find("[name=weight]").removeAttr("data-dmas");
$(document).find("[name=qty]").removeAttr("data-dmas");
$(document).find("[name=rate]").removeAttr("data-dmas");	
$(document).find("[name=feet]").attr("data-dmas","feet-add,rate-multiply,amount-result");	
$(document).find("[name=rate]").attr("data-dmas","feet-add,rate-multiply,amount-result");	
$(document).find("[name=feet]").trigger("keyup");
}
else if(val=="kg"){
$(document).find("[name=feet]").removeAttr("data-dmas");
$(document).find("[name=qty]").removeAttr("data-dmas");
$(document).find("[name=rate]").removeAttr("data-dmas");	
$(document).find("[name=weight]").attr("data-dmas","weight-add,rate-multiply,amount-result");	
$(document).find("[name=rate]").attr("data-dmas","weight-add,rate-multiply,amount-result");
$(document).find("[name=weight]").trigger("keyup");	
}
else if(val=="pcs"){
$(document).find("[name=feet]").removeAttr("data-dmas");
$(document).find("[name=weight]").removeAttr("data-dmas");
$(document).find("[name=rate]").removeAttr("data-dmas");	
$(document).find("[name=qty]").attr("data-dmas","qty-add,rate-multiply,amount-result");	
$(document).find("[name=rate]").attr("data-dmas","qty-add,rate-multiply,amount-result");
$(document).find("[name=qty]").trigger("keyup");	
}
});
$(document).on("change","[name=unit_e]",function(){
var val=$(this).val();
if(val=="feet"){
$(document).find("[name=weight_e]").removeAttr("data-dmas");
$(document).find("[name=qty_e]").removeAttr("data-dmas");
$(document).find("[name=rate_e]").removeAttr("data-dmas");	
$(document).find("[name=feet_e]").attr("data-dmas","feet_e-add,rate_e-multiply,amount_e-result");	
$(document).find("[name=rate_e]").attr("data-dmas","feet_e-add,rate_e-multiply,amount_e-result");	
$(document).find("[name=feet_e]").trigger("keyup");
}
else if(val=="kg"){
$(document).find("[name=feet_e]").removeAttr("data-dmas");
$(document).find("[name=qty_e]").removeAttr("data-dmas");
$(document).find("[name=rate_e]").removeAttr("data-dmas");	
$(document).find("[name=weight_e]").attr("data-dmas","weight_e-add,rate_e-multiply,amount_e-result");	
$(document).find("[name=rate_e]").attr("data-dmas","weight_e-add,rate_e-multiply,amount_e-result");
$(document).find("[name=weight_e]").trigger("keyup");	
}
else if(val=="pcs"){
$(document).find("[name=feet_e]").removeAttr("data-dmas");
$(document).find("[name=weight_e]").removeAttr("data-dmas");
$(document).find("[name=rate_e]").removeAttr("data-dmas");	
$(document).find("[name=qty_e]").attr("data-dmas","qty_e-add,rate_e-multiply,amount_e-result");	
$(document).find("[name=rate_e]").attr("data-dmas","qty_e-add,rate_e-multiply,amount_e-result");
$(document).find("[name=qty_e]").trigger("keyup");	
}
});
function loadVoucheredit(vtype){
var target2=$(".modal-edit-row").find(".modal-body");
target2.customPreloader("show");	
 $.ajax({
 url:"<?= base_url("memo/memo-voucher-edit-type");?>",
 method:"post",
 data:{type:vtype},
 dataType:"json"	
 }).done(function(response){	
 target2.html(response.data2);
 });		
}
</script>