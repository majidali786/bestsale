<div class="col-sm-12 data-rows flip-scroll">
<table class="table table-bordered table-striped table-condensed flip-content">
<thead class="flip-content theme-color border-theme">
<tr>
<th>#</th>
<th style="width:40%">Product</th>
<th style="width:10%">Unit</th>
<th style="width:10%">Weight</th>
<th style="width:10%">Qty</th>
<th style="width:10%">Feet</th>
<th style="width:10%">Rate</th>
<th style="width:10%">Amount</th>
</tr>
</thead>
<tbody class="theme-border">

</tbody>
<tfoot class="border-theme">
<tr>
<th colspan="4">Total</th>
<td class="theme-bg"><input type="text" name="tqty" /></td>
<td colspan="2"></td>
<td class="theme-bg"><input type="text" name="tamount" /></td>
</tr>
</tfoot>
</table>
</div>
