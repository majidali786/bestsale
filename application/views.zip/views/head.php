<head>
<meta charset="utf-8" />
<title>Inayat Pipe | Solution Experts</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta content="Accounting Solution,Accounting Software,Web Portal,CMS,website,Accounts" name="description" />
<meta content="" name="author" />
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/plugins/font-awesome/css/font-awesome.min.css");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/plugins/simple-line-icons/simple-line-icons.min.css?1");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/plugins/bootstrap/css/bootstrap.min.css?1");?>" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->
<!--  Datatables library start-->
<?php 
if(in_array('datatable',$libraries)){	
?>
<link href="<?= base_url("assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/plugins/datatables/datatables.min.css");?>" rel="stylesheet" type="text/css" />
<?php 
}
?>
<!--  Datatables library end-->

<!--  Select 2 library start-->
<link href="<?= base_url("assets/global/plugins/select2/css/select2.min.css");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/plugins/optiscroll/css/optiscroll.css");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/plugins/select2/css/select2-bootstrap.min.css?1");?>" rel="stylesheet" type="text/css" />
<!--  Select 2 library end-->



<!-- BEGIN THEME GLOBAL STYLES -->
<link href="<?= base_url("assets/global/css/plugins.min.css");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/css/components.min.css?3");?>" rel="stylesheet" id="style_components" type="text/css" />

<link href="<?= base_url("assets/apps/css/todo.min.css?1");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/apps/css/todo-2.min.css?2");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/global/css/voucher-control.css");?>" rel="stylesheet" id="style_components" type="text/css" />
<!-- END THEME GLOBAL STYLES -->
<!-- BEGIN THEME LAYOUT STYLES -->
<link href="<?= base_url("assets/layouts/layout3/css/layout.min.css?2");?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url("assets/layouts/layout3/css/themes/default.min.css");?>" rel="stylesheet" type="text/css" id="style_color" />
<link href="<?= base_url("assets/layouts/layout3/css/custom.min.css");?>" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?= base_url("favicon.ico");?>" />
<link href="<?= base_url("assets/pages/css/preloader.css")?>" class="cp-pen-styles" rel="stylesheet" type="text/css" />

<script src="<?= base_url("assets/global/plugins/jquery.min.js");?>" type="text/javascript"></script>
</head>